Plugin: CBEARNING
Donate link: http://www.ifyouknowit.com/
Tags: cbearning,clickbank affiliate


== Description ==

CBEARNING allows you to import the ENTIRE ClickBank Marketplace into your WordPress blog in seconds while 
other ClickBank plugins require you to manually enter ClickBank products one by one.
want professional version check <a href="http://magento.ifyouknowit.com">Go pro</a>


== Installation ==

1. Just create a directory xmlfeed inside your wordpress installation ex : /var/www/wordpress/xmlfeed and give full write permission 777.
2. Copy the zip file into plugin folder and activate the plugin from admin panel
3. Click on import data from CBEARNING menu, it will take few min.
4. Just Place [CB_EARNING] in any post/page
5. See the site, products list must appear.
6. [CB_EARNINGS    cbtext="music"]
7. [CB_EARNINGS cbtext="[php] if(isset($_POST['cbtext'])){ echo $_POST['cbtext'];} [/php]"] (no need to install any plugin to allow php)

Note : Please ensure that simple xml is installed


