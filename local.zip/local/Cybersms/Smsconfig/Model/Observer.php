<?php
class Cybersms_Smsconfig_Model_Observer {
    public function customerRegisterSuccess(Varien_Event_Observer $observer) {
        $event = $observer->getEvent();
        $customer = $event->getCustomer();
        
        // sms has to send using email else phone number has to be accepted during regitration.
        // $email = $customer->getEmail();
        // $phone=$customer->getPrimaryBillingAddress()->getTelephone();
        if($phone) {
            // Create custom code over here as per your requirements !
             //  Mage::log('custimer: signed:'.$phone);
        }
        
 $template=Mage::getStoreConfig('smsconfigtab_sec/smsconfigtab_group/smsconfigtab_mailtemplate',Mage::app()->getStore());
 $sgateway=Mage::getStoreConfig('smsconfigtab_sec/smsconfigtab_group/smsconfigtab_singlesms',Mage::app()->getStore());
 $mgateway=Mage::getStoreConfig('smsconfigtab_sec/smsconfigtab_group/smsconfigtab_multiplesms',Mage::app()->getStore());
      
       Mage::log('custimer: signed:'.$sgateway,null,'mylog.txt'); 
       
       Mage::log('custimer: signed:'.$mgateway,null,'mylog.txt'); 
        Mage::log('custimer: signed:'.$template,null,'mylog.txt');     
        return $this;
    }
    
    /**
    
    before order is placed
    */
    
    public function salesOrderPlacedBef(Varien_Event_Observer $observer) {
        $order = $observer->getEvent()->getOrder();
        mage::log($order->getId());
        $phone=$observer->getOrder()->getBillingAddress()->getTelephone();
            // mage::log($order->getId());
            if($phone) {
            // Create custom code over here as per your requirements !
               mage::log('order before'.$phone);
            }
            
  $template=Mage::getStoreConfig('smsconfigtab_sec/smsconfigtab_group/smsconfigtab_mailtemplate',Mage::app()->getStore());
 $sgateway=Mage::getStoreConfig('smsconfigtab_sec/smsconfigtab_group/smsconfigtab_singlesms',Mage::app()->getStore());
 $mgateway=Mage::getStoreConfig('smsconfigtab_sec/smsconfigtab_group/smsconfigtab_multiplesms',Mage::app()->getStore());
      
       Mage::log('custimer: signed:'.$sgateway,null,'mylog.txt'); 
       
       Mage::log('custimer: signed:'.$mgateway,null,'mylog.txt'); 
        Mage::log('custimer: signed:'.$template,null,'mylog.txt');     
        return $this;
    }
    
    
    /**
      before sales order status is  updated
    
    */
    
    public function salesOrderStatusBef(Varien_Event_Observer $observer) {
            $event = $observer->getEvent();
            $order = $event->getOrder();
            
           
            
   
    
 $template=Mage::getStoreConfig('smsconfigtab_sec/smsconfigtab_group/smsconfigtab_mailtemplate',Mage::app()->getStore());
 $sgateway=Mage::getStoreConfig('smsconfigtab_sec/smsconfigtab_group/smsconfigtab_mailtemplate',Mage::app()->getStore());
 $mgateway=Mage::getStoreConfig('smsconfigtab_sec/smsconfigtab_group/smsconfigtab_mailtemplate',Mage::app()->getStore());
    
            $phone=$observer->getOrder()->getBillingAddress()->getTelephone();
            // mage::log($order->getId());
            if($phone) {
            // Create custom code over here as per your requirements !
               mage::log('order status update'.$phone,null,'mylog.txt');
            }
 $template=Mage::getStoreConfig('smsconfigtab_sec/smsconfigtab_group/smsconfigtab_mailtemplate',Mage::app()->getStore());
 $sgateway=Mage::getStoreConfig('smsconfigtab_sec/smsconfigtab_group/smsconfigtab_singlesms',Mage::app()->getStore());
 $mgateway=Mage::getStoreConfig('smsconfigtab_sec/smsconfigtab_group/smsconfigtab_multiplesms',Mage::app()->getStore());
      
       Mage::log('custimer: signed:'.$sgateway,null,'mylog.txt'); 
       
       Mage::log('custimer: signed:'.$mgateway,null,'mylog.txt'); 
        Mage::log('custimer: signed:'.$template,null,'mylog.txt');     
        return $this;
    }
}
?>
