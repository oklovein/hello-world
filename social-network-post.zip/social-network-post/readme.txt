=== Mapworks ===
Contributors: Social Network Post, automattic, prakash,SNP
Tags: Social Network Post,Post automatic to Facebook,SNP, comments, social, friends, social plugins, page open graph, publish Facebook
Requires at least: 3.3
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html


Add Social Network Plugin with the ability to publish new posts to the Timeline on Social Network Site like facebook.

== Description ==
The Social Network Plugin. enables sharing new posts to an author's Facebook Timeline.

= Features =
Add/Edit text in wordpress , click publish. It gets published in wordpress automatic
Get Long Live Auth token at click of a link which gets saved automatic.

Example usage:
You will see two menus 1. SNP settings 2. Get Token
Go to SNP settings and set facebook api and facebook secret.
Click on the link to login to facebook and get authtoken.
After facebook allow access, url redirection to your wordpress site will happen.
Your auth token gets saved and will appear on SNP Settings.





